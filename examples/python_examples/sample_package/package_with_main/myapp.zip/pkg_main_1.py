def pkg_main_1():
    print("pkg_main_1")
